# CLAUDE.md — プロジェクト管理ルール

## このプロジェクトの目的

社内チャットの内容を読み込み、その日の業務内容・決定事項・未完了タスク・課題・翌日の予定を整理して、
Google Docs へ貼り付けられる業務日報を作成する Claude スキルを開発する。

- 導入企業固有の情報はまだ存在しないため、架空のデモデータで動作する汎用モックを作成する。
- 利用企業は `references/company-settings.md` などの設定ファイルを書き換えるだけで自社用に調整できる構成にする。

## 作業の進め方(必ず守ること)

1. **フェーズ単位で作業する。** 一度にすべてを作らない。
2. **勝手に次のフェーズへ進まない。** 依頼者が「次のフェーズへ進んでください」と伝えるまで待つ。
3. **各フェーズ終了時に検証し、成果物一覧と確認結果を報告する。**
4. **既存ファイルを変更する際は、他ファイルへの影響を確認してから変更する。**
5. **推測で仕様を追加しない。** 不明点は汎用的な仮設定でモックを作り、その旨を明記する。
6. **チャットに書かれていない情報を推測しない。** 担当者・期限・完了状況が不明な場合は「不明」とするか、利用者へ確認する。

## 設計上のルール

- 導入企業固有の情報をコードやスキル本体(SKILL.md など)へ直接書き込まない。
- 企業固有の設定は `references/company-settings.md` だけで変更できる構造にする。
- 初期版では Slack / Chatwork / Teams / Google Docs などの API 連携を実装しない。
- 外部連携は `optional-integration/` に分離し、スキル本体がなくても動く状態を保つ。
- 個人情報・機密情報・パスワードなどの扱いに関する注意事項を明記する。

## 表現のルール

- 非エンジニアでも設定・利用できる説明を優先する。
- 専門用語を使う場合は、簡単な補足を付ける。

## 開発フェーズ

| フェーズ | 内容 | 状態 |
|---|---|---|
| 0 | プロジェクト初期化 | 完了 |
| 1 | 要件定義(references/ 各ファイル作成) | 完了 |
| 2 | デモデータ作成(assets/) | 完了 |
| 3 | SKILL.md 作成 | 完了 |
| 4 | 動作テストと修正(test-results/) | 完了 |
| 5 | 利用者向けマニュアル(README.md 完成) | 完了 |
| 6 | Google Docs 連携サンプル(optional-integration/) | 完了 |
| 7 | 最終確認・納品準備 | 完了 |

## 最終的なフォルダ構成

```text
chat-daily-report/
├── CLAUDE.md                     … このファイル(プロジェクト管理ルール)
├── README.md                     … 利用者向けマニュアル
├── SKILL.md                      … スキル本体(処理手順の定義)
├── agents/
│   └── openai.yaml               … エージェント定義
├── references/
│   ├── company-settings.md       … 企業ごとの設定(利用者が編集する唯一のファイル)
│   ├── daily-report-template.md  … 日報テンプレート
│   ├── processing-rules.md       … チャット分析・抽出の処理ルール
│   ├── security-rules.md         … 個人情報・機密情報の扱いルール
│   └── customization-guide.md    … カスタマイズ手引き
├── assets/
│   ├── demo-chat.txt             … 架空のデモチャット
│   ├── demo-daily-report.md      … 正解となる業務日報
│   ├── customer-checklist.md     … 導入時チェックリスト
│   └── test-cases.md             … テストケース定義
├── optional-integration/
│   ├── README.md                 … Google Docs 連携の導入手順
│   └── google-docs-sample.gs     … GAS サンプル
└── test-results/
    └── test-report.md            … テスト結果
```
